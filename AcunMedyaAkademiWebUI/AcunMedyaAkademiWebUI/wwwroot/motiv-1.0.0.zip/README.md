# Motiv.

### Quick Start

- Step - 1: Clone the repository: <code>git clone https://github.com/themewagon/motiv.git</code>
- Step - 2: Install the required Node.js packages: <code>npm install</code>
- Step - 3: Run the application: <code>npm run dev</code>

### Live Link: https://themewagon.github.io/motiv
