export default ['0px 10px 110px 1px rgba(59, 59, 59, 0.08)'];
